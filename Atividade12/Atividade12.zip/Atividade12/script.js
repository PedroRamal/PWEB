function Retangulo(altura, largura){
        this.altura = altura;
        this.largura = largura;

        this.CalcArea = function(){
            return altura * largura;
        }
    }
   
var alt = prompt("Informe a Altura: ");
var larg = prompt("Informe a Largura: ");
var retangulo = new Retangulo(alt, larg);

alert("Área do retângulo: " + retangulo.CalcArea())


