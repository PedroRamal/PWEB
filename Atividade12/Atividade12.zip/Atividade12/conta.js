
function Conta(){

    this.getNome = function(){
        return this.nome;
    }

    this.setNome = function(nome){
        this.nome = nome;
    }

    this.getBanco = function(){
        return this.banco;
    }

    this.setBanco = function(banco){
        this.banco = banco;
    }

    this.getNumConta = function(){
        return this.numConta;
    }

    this.setNumConta = function(numConta){
        this.numConta = numConta;
    }

    this.getSaldo = function(){
        return this.saldo;
    }

    this.setSaldo = function(saldo){
        this.saldo = saldo;
    }   
}

function Corrente(){ 

    this.getSaldoEspecial = function(){
        return this.saldoEspecial;
    };

    this.setSaldoEspecial = function(saldoEspecial){
        this.saldoEspecial = saldoEspecial;
    };
}

function Poupanca(){ 
    
    this.getJuros = function(){
        return this.juros;
    };
    
    this.setJuros = function(juros){
        this.juros = juros;
    };

    this.getDataVencimento = function(){
        return this.dataVencimento;
    };
    
    this.setDataVencimento = function(dataVencimento){
        this.dataVencimento = dataVencimento;
    };
}

Corrente.prototype = new Conta();
Poupanca.prototype = new Conta();

objCorrente = new Corrente();
objPoupanca = new Poupanca();

objPoupanca.setNome("Jeniffer");
objPoupanca.setBanco("NuBank");
objPoupanca.setNumConta("12");
objPoupanca.setSaldo(50000);
objPoupanca.setJuros(15);
objPoupanca.setDataVencimento("17/03/2025");
objCorrente.setNome("Pedro");
objCorrente.setBanco("Itau");
objCorrente.setNumConta("11");
objCorrente.setSaldo(3300);
objCorrente.setSaldoEspecial(10000);


alert("Dados da conta corrente:<br>Nome: " + objCorrente.getNome() + 
                "\nBanco: " + objCorrente.getBanco() + 
                "\nNúmero da Conta: " + objCorrente.getNumConta() +
                "\nSaldo: " + objCorrente.getSaldo() +
                "\nSaldo Especial: " + objCorrente.getSaldoEspecial());

alert("Dados da conta poupança: Nome: " + objPoupanca.getNome() + 
                "\nBanco: " + objPoupanca.getBanco() + 
                "\nNúmero da Conta: " + objPoupanca.getNumConta() +
                "\nSaldo: " + objPoupanca.getSaldo() +
                "\nJuros: " + objPoupanca.getJuros() +
                "\nData de vencimento: " + objPoupanca.getDataVencimento());